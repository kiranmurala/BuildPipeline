# SETI's Playground

Welcome to SETI's playground!
SETI set up this repository to let you practice with creating a build pipeline from scratch. 
We do give you a few hints to get started though ;).

To let you practice we created a couple of assignments to complete.

## Assignment 1: Implement stages in the build pipeline.

We ask you to setup two stages in the build pipeline:

1. A test stage running the "npm test" command that runs all the tests of the React SPA.
2. A build stage running the "npm build" command that packages the SPA in an artifact ready for deployment.

Note: You can test the npm commands by running them locally. 

Bonus points: Implement your pipeline using Yarn to make it faster!

Reference:

- [Jenkins documentation](https://jenkins.io/doc/)
- [Jenkins pipeline syntax](https://jenkins.io/doc/book/pipeline/syntax/)
- [Yarn documentation](https://yarnpkg.com/en/)

# Assignment 2: Improve the pipeline

Only the code in the master branch is accepted and of sufficient quality to be released to production, please adjust your pipeline to make sure that the stage for packaging your product only runs on the master branch.

Bonus points: Gather the test results in your pipeline in a post action and pass them to Jenkins to be displayed.

Reference:

- [Jenkins pipeline syntax](https://jenkins.io/doc/book/pipeline/syntax/)
- [Gathering test results](https://jenkins.io/doc/pipeline/tour/tests-and-artifacts/)

# Assignment 3: Implement SonarQube in the pipeline

We want to keep track of the quality of the code in our pipeline. To do so we ask you to implement SonarQube scanning in the pipeline.

1. Add a stage to the pipeline for SonarQube scanning
2. Restrict the stage to only run on the master branch
3. Call the sonar-scanner process with the properties to run a full scan (Don't worry we made it available in the build environment ;))

Note: Only mind about the project specific parameters for the Sonar Scanner. The connection to the server is ensured by SETI.

Bonus points: Make sure that Sonar excludes all your test directories.

Reference:

- [Jenkins pipeline syntax](https://jenkins.io/doc/book/pipeline/syntax/)
- [Sonar scanner documentation](https://docs.sonarqube.org/display/SCAN/Analyzing+with+SonarQube+Scanner)

# Assignment 4: Give pull request feedback

We would like to see feedback on our pull request from SonarQube. The sooner we know our quality issues the less cost it is to fix it, shift left!

1. Remove the restriction on your Sonar stage and let it run on all branches
2. Adjust the call to the sonar-scanner process to scan with preview settings and post the changes to a pull request on GitHub

Hint: The following environment variables are available:

- GITHUB\_API\_URL: URL to GitHub enterprise
- GITHUB\_API\_KEY: Token to authenticate to GitHub enterprise
- CHANGE\_ID: The pull request number to post your status to

Reference:

- [Working with the Environment](https://jenkins.io/doc/book/pipeline/jenkinsfile/#working-with-the-environment)
- [How to work with GitHub plugin](https://docs.sonarqube.org/display/PLUG/GitHub+Plugin)