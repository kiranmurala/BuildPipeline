// Snippet from https://github.com/facebook/jest/issues/104#issuecomment-252786382
// This makes Jest generate JUnit XML test results, which can be included in Jenkins

const paths = require('./paths');
const reporters = require('jasmine-reporters');
const reporter = new reporters.JUnitXmlReporter({
  // Jest runs many instances of Jasmine in parallel. Force distinct file output
  // per test to avoid collisions.
  consolidateAll: false,
  filePrefix: 'jest-junit-result-',
  savePath: paths.reports + '/junit-results/'
});
jasmine.getEnv().addReporter(reporter);
